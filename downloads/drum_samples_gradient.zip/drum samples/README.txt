Drum samples are provided royalty free.
Feel free to use them, redistribute them, put them in audacity to screenshot their waveforms so as to print them and include them in a modern art project, whatever.
That being said, please keep this README with the samples, so I can include this link to my soundcloud: https://soundcloud.com/gradientelectro
Have a great day.