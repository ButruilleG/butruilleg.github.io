Presets are provided royalty free.
Feel free to use and redistribute them as you see fit.
Note that these are in the .fxb file format, which means that Hybrid 3 will not read them-- you'll need to open these through your DAW.
Please keep this readme with the rest of these files, so I can include this link to my soundcloud: https://soundcloud.com/gradientelectro
Have a great day!